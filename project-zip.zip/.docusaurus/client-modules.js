export default [
  require("D:\\dev_packages\\pdf maker\\euv-guide-site\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("D:\\dev_packages\\pdf maker\\euv-guide-site\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("D:\\dev_packages\\pdf maker\\euv-guide-site\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("D:\\dev_packages\\pdf maker\\euv-guide-site\\src\\css\\custom.css"),
  require("D:\\dev_packages\\pdf maker\\euv-guide-site\\src\\css\\print.css"),
];
