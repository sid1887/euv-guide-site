import lunr from "D:\\dev_packages\\pdf maker\\euv-guide-site\\node_modules\\lunr\\lunr.js";
export const removeDefaultStopWordFilter = [];
export const language = ["en"];
export const searchIndexUrl = "search-index{dir}.json";
export const searchResultLimits = 8;
export const fuzzyMatchingDistance = 1;